// Configure marked options
marked.setOptions({
    gfm: true, // GitHub Flavored Markdown
    breaks: true, // Convert line breaks to <br>
    headerIds: false, // Don't add IDs to headers
    mangle: false, // Don't mangle email addresses
    sanitize: false, // Don't sanitize HTML
    smartLists: true, // Use smarter list behavior
    smartypants: true, // Use smart punctuation
    xhtml: false // Don't use XHTML
});

// Function to add chat button
function addChatButton(settings) {
    // Specific function to handle a single button group
    function addButtonToGroup(btnGroup) {
        if (btnGroup.querySelector('.paperless-ai-chat-btn')) {
            return;
        }
  
        const downloadBtn = btnGroup.querySelector('a[href*="/api/documents/"][href*="/download/"]');
        if (!downloadBtn) {
            return;
        }
  
        const documentId = downloadBtn.getAttribute('href').match(/\/documents\/(\d+)\//)?.[1];
        if (!documentId) {
            return;
        }
  
        const chatButton = document.createElement('a');
        chatButton.className = 'btn btn-sm btn-outline-secondary paperless-ai-chat-btn';
        chatButton.href = '#';
        chatButton.setAttribute('_ngcontent-ng-c705869026', '');
        chatButton.title = 'Chat with AI about this document';
  
        const icon = document.createElement('i-bs');
        icon.setAttribute('_ngcontent-ng-c705869026', '');
        icon.setAttribute('name', 'chat-dots');
        icon.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                <path d="M2.165 15.803a.5.5 0 0 1-.498-.55c.01-.1.03-.21.057-.315.057-.223.064-.495.064-.769V8c0-4.418 3.582-8 8-8s8 3.582 8 8-3.582 8-8 8c-.774 0-1.526-.07-2.25-.204a.5.5 0 0 1-.351-.671z"/>
            </svg>
        `;
        
        chatButton.appendChild(icon);
  
        chatButton.addEventListener('click', async (e) => {
            e.preventDefault();
            try {
                console.log('Initializing chat for document:', documentId);
                const initResponse = await fetch(`${settings.aiUrl}/chat/init/${documentId}`, {
                    method: 'GET',
                    headers: {
                        'x-api-key': settings.apiKey
                    }
                });
                
                if (!initResponse.ok) {
                    throw new Error('Failed to initialize chat');
                }
  
                openChatInterface(documentId, settings);
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to initialize chat. Please check your settings.');
            }
        });
  
        btnGroup.appendChild(chatButton);
    }
  
    function processPage() {
        const btnGroups = document.querySelectorAll('.card-footer .btn-group, .action-buttons .btn-group');
        btnGroups.forEach(addButtonToGroup);
    }
  
    processPage();
  
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                const btnGroups = document.querySelectorAll('.card-footer .btn-group, .action-buttons .btn-group');
                btnGroups.forEach(group => {
                    if (!group.querySelector('.paperless-ai-chat-btn')) {
                        addButtonToGroup(group);
                    }
                });
            }
        }
    });
  
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
  }
  
// Chat interface implementation
function openChatInterface(documentId, settings) {
    if (!document.querySelector('.paperless-ai-chat-container')) {
        const chatContainer = document.createElement('div');
        chatContainer.className = 'paperless-ai-chat-container';
        
        // Add style for Markdown formatting
        const style = document.createElement('style');
        style.textContent = `
            .message.assistant {
                white-space: pre-wrap;
                line-height: 1.5;
            }
            .message.assistant p {
                margin: 0.5em 0;
            }
            .message.assistant pre {
                background-color: #f6f8fa;
                border-radius: 6px;
                padding: 16px;
                overflow: auto;
                font-family: monospace;
                margin: 0.5em 0;
            }
            .message.assistant code {
                background-color: rgba(175, 184, 193, 0.2);
                border-radius: 6px;
                padding: 0.2em 0.4em;
                font-family: monospace;
            }
            .message.assistant pre code {
                background-color: transparent;
                padding: 0;
            }
            .message.assistant ul, .message.assistant ol {
                margin: 0.5em 0;
                padding-left: 2em;
            }
            .message.assistant blockquote {
                border-left: 4px solid #dfe2e5;
                color: #6a737d;
                margin: 0.5em 0;
                padding-left: 1em;
            }
            .message.assistant table {
                border-collapse: collapse;
                margin: 0.5em 0;
                width: 100%;
            }
            .message.assistant th, .message.assistant td {
                border: 1px solid #dfe2e5;
                padding: 6px 13px;
            }
            .message.assistant th {
                background-color: #f6f8fa;
            }
            .message.assistant hr {
                border: 0;
                border-top: 1px solid #dfe2e5;
                margin: 1em 0;
            }
        `;
        document.head.appendChild(style);

        chatContainer.innerHTML = `
            <div class="chat-header">
                <h3>Document Chat</h3>
                <button class="close-btn">&times;</button>
            </div>
            <div class="chat-messages"></div>
            <div class="chat-input">
                <input type="text" placeholder="Type your message..." autofocus>
                <button class="send-btn">Send</button>
            </div>
        `;

        document.body.appendChild(chatContainer);

        const messagesContainer = chatContainer.querySelector('.chat-messages');
        const input = chatContainer.querySelector('input');
        const sendButton = chatContainer.querySelector('.send-btn');
        const closeButton = chatContainer.querySelector('.close-btn');

        async function sendMessage() {
            const message = input.value.trim();
            if (!message) return;

            input.value = '';
            input.disabled = true;
            sendButton.disabled = true;

            const userMessageElement = document.createElement('div');
            userMessageElement.className = 'message user';
            userMessageElement.textContent = message;
            messagesContainer.appendChild(userMessageElement);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;

            const assistantMessageElement = document.createElement('div');
            assistantMessageElement.className = 'message assistant';
            messagesContainer.appendChild(assistantMessageElement);

            try {
                const response = await fetch(`${settings.aiUrl}/chat/message`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'x-api-key': settings.apiKey
                    },
                    body: JSON.stringify({ documentId, message })
                });

                if (!response.ok) {
                    throw new Error('Failed to send message');
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let fullText = '';

                while (true) {
                    const { done, value } = await reader.read();
                    
                    if (done) break;
                    
                    buffer += decoder.decode(value, { stream: true });
                    
                    const lines = buffer.split('\n');
                    buffer = lines.pop() || '';
                    
                    for (const line of lines) {
                        if (line.startsWith('data: ')) {
                            const data = line.slice(6);
                            if (data === '[DONE]') {
                                continue;
                            }
                            try {
                                const parsed = JSON.parse(data);
                                if (parsed.content) {
                                    fullText += parsed.content;
                                    // Convert Markdown to HTML and set it
                                    assistantMessageElement.innerHTML = marked.parse(fullText);
                                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                                }
                            } catch (e) {
                                console.error('Error parsing SSE data:', e);
                            }
                        }
                    }
                }

            } catch (error) {
                console.error('Error sending message:', error);
                
                const errorMessageElement = document.createElement('div');
                errorMessageElement.className = 'message error';
                errorMessageElement.textContent = 'Sorry, there was an error sending your message. Please try again.';
                messagesContainer.appendChild(errorMessageElement);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            } finally {
                input.disabled = false;
                sendButton.disabled = false;
                input.focus();
            }
        }

        sendButton.addEventListener('click', sendMessage);
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        input.focus();

        closeButton.addEventListener('click', () => {
            chatContainer.remove();
        });

        document.addEventListener('click', (e) => {
            if (!chatContainer.contains(e.target) && 
                !e.target.closest('.paperless-ai-chat-btn')) {
                chatContainer.remove();
            }
        });
    }
}
  
  async function initialize() {
    try {
        const settings = await chrome.storage.sync.get(['paperlessUrl', 'aiUrl', 'apiKey']);
        
        if (!settings.paperlessUrl?.trim() || !settings.aiUrl?.trim() || !settings.apiKey?.trim()) {
            console.warn('Paperless-AI Chat: Configuration incomplete');
            return;
        }
  
        console.log('Paperless-AI Chat: Initializing with settings:', {
            paperlessUrl: settings.paperlessUrl,
            aiUrl: settings.aiUrl,
            hasApiKey: !!settings.apiKey
        });
  
        addChatButton(settings);
        
    } catch (error) {
        console.error('Paperless-AI Chat: Initialization error:', error);
    }
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
  
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        console.log('Paperless-AI Chat: URL changed, reinitializing...');
        initialize();
    }
  }).observe(document, {subtree: true, childList: true});