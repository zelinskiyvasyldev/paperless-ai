document.addEventListener('DOMContentLoaded', async () => {
    const statusContainer = document.getElementById('statusContainer');
    const settingsBtn = document.getElementById('settingsBtn');
  
    // Load settings
    const settings = await chrome.storage.sync.get(['paperlessUrl', 'aiUrl', 'apiKey']);
  
    // Check if settings are configured
    if (settings.paperlessUrl && settings.aiUrl && settings.apiKey) {
      statusContainer.classList.add('connected');
      statusContainer.textContent = 'Extension is configured';
    } else {
      statusContainer.classList.add('not-connected');
      statusContainer.textContent = 'Please configure the extension settings';
    }
  
    // Open settings page
    settingsBtn.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });
  });
  
  // background.js
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
      // Open options page on installation
      chrome.runtime.openOptionsPage();
    }
  });