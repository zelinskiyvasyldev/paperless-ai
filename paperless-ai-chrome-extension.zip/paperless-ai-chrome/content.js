// Function to add chat button
function addChatButton(settings) {
    // Specific function to handle a single button group
    function addButtonToGroup(btnGroup) {
      // Check if button already exists in this group
      if (btnGroup.querySelector('.paperless-ai-chat-btn')) {
        return;
      }
  
      // Get the download button to extract the document ID
      const downloadBtn = btnGroup.querySelector('a[href*="/api/documents/"][href*="/download/"]');
      if (!downloadBtn) {
        return;
      }
  
      // Extract document ID from download URL
      const documentId = downloadBtn.getAttribute('href').match(/\/documents\/(\d+)\//)?.[1];
      if (!documentId) {
        return;
      }
  
      // Create chat button following Angular's structure
      const chatButton = document.createElement('a');
      chatButton.className = 'btn btn-sm btn-outline-secondary paperless-ai-chat-btn';
      chatButton.href = '#';
      chatButton.setAttribute('_ngcontent-ng-c705869026', ''); // Match Angular's attribute
      chatButton.title = 'Chat with AI about this document';
  
      // Create icon container matching Angular's structure
      const icon = document.createElement('i-bs');
      icon.setAttribute('_ngcontent-ng-c705869026', '');
      icon.setAttribute('name', 'chat-dots');
      icon.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
          <path d="M2.165 15.803a.5.5 0 0 1-.498-.55c.01-.1.03-.21.057-.315.057-.223.064-.495.064-.769V8c0-4.418 3.582-8 8-8s8 3.582 8 8-3.582 8-8 8c-.774 0-1.526-.07-2.25-.204a.5.5 0 0 1-.351-.671z"/>
        </svg>
      `;
      
      chatButton.appendChild(icon);
  
      // Add click handler
      chatButton.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
          console.log('Initializing chat for document:', documentId);
          const initResponse = await fetch(`${settings.aiUrl}/chat/init/${documentId}`, {
            method: 'GET',
            headers: {
              'x-api-key': settings.apiKey
            }
          });
          
          if (!initResponse.ok) {
            throw new Error('Failed to initialize chat');
          }
  
          openChatInterface(documentId, settings);
        } catch (error) {
          console.error('Error:', error);
          alert('Failed to initialize chat. Please check your settings.');
        }
      });
  
      // Insert button before the last button in group
      btnGroup.appendChild(chatButton);
    }
  
    // Handle both document cards and detail view
    function processPage() {
      // Find all button groups in document cards
      const btnGroups = document.querySelectorAll('.card-footer .btn-group, .action-buttons .btn-group');
      btnGroups.forEach(addButtonToGroup);
    }
  
    // Initial processing
    processPage();
  
    // Set up a more specific observer that watches for Angular's rendering
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.addedNodes.length) {
          const btnGroups = document.querySelectorAll('.card-footer .btn-group, .action-buttons .btn-group');
          btnGroups.forEach(group => {
            if (!group.querySelector('.paperless-ai-chat-btn')) {
              addButtonToGroup(group);
            }
          });
        }
      }
    });
  
    // Observe the entire document for Angular's dynamic updates
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['_ngcontent-ng-c705869026']
    });
  }
  
  // Chat interface implementation
  function openChatInterface(documentId, settings) {
    // Create chat container if it doesn't exist
    if (!document.querySelector('.paperless-ai-chat-container')) {
      const chatContainer = document.createElement('div');
      chatContainer.className = 'paperless-ai-chat-container';
      chatContainer.innerHTML = `
        <div class="chat-header">
          <h3>Document Chat</h3>
          <button class="close-btn">&times;</button>
        </div>
        <div class="chat-messages"></div>
        <div class="chat-input">
          <input type="text" placeholder="Type your message..." autofocus>
          <button class="send-btn">Send</button>
        </div>
      `;
  
      document.body.appendChild(chatContainer);
  
      // Set up chat handlers
      const messagesContainer = chatContainer.querySelector('.chat-messages');
      const input = chatContainer.querySelector('input');
      const sendButton = chatContainer.querySelector('.send-btn');
      const closeButton = chatContainer.querySelector('.close-btn');
  
      async function sendMessage() {
        const message = input.value.trim();
        if (!message) return;
  
        // Clear input immediately and add user message to chat
        input.value = '';
        const userMessageElement = document.createElement('div');
        userMessageElement.className = 'message user';
        userMessageElement.textContent = message;
        messagesContainer.appendChild(userMessageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
  
        // Add typing indicator
        const typingIndicator = document.createElement('div');
        typingIndicator.className = 'typing-indicator';
        typingIndicator.innerHTML = '<span></span><span></span><span></span>';
        messagesContainer.appendChild(typingIndicator);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
  
        try {
          const response = await fetch(`${settings.aiUrl}/chat/message`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-api-key': settings.apiKey
            },
            body: JSON.stringify({ documentId, message })
          });
  
          // Remove typing indicator
          typingIndicator.remove();
  
          if (!response.ok) {
            throw new Error('Failed to send message');
          }
  
          const data = await response.json();
          
          // Add assistant's response
          const assistantMessageElement = document.createElement('div');
          assistantMessageElement.className = 'message assistant';
          assistantMessageElement.textContent = data.reply;
          messagesContainer.appendChild(assistantMessageElement);
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } catch (error) {
          console.error('Error sending message:', error);
          
          // Remove typing indicator
          typingIndicator.remove();
          
          // Add error message
          const errorMessageElement = document.createElement('div');
          errorMessageElement.className = 'message assistant';
          errorMessageElement.textContent = 'Sorry, there was an error sending your message. Please try again.';
          messagesContainer.appendChild(errorMessageElement);
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
      }
  
      // Send message handlers
      sendButton.addEventListener('click', sendMessage);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault(); // Prevent default to avoid newline
          sendMessage();
        }
      });
  
      // Focus input when chat opens
      input.focus();
  
      // Close handler
      closeButton.addEventListener('click', () => {
        chatContainer.remove();
      });
      
      // Click outside to close
      document.addEventListener('click', (e) => {
        if (!chatContainer.contains(e.target) && 
            !e.target.closest('.paperless-ai-chat-btn')) {
          chatContainer.remove();
        }
      });
    }
  }
  
  // Initialize extension
  function initialize() {
    // Get settings and initialize button
    chrome.storage.sync.get(['paperlessUrl', 'aiUrl', 'apiKey'], function(settings) {
      if (!settings.paperlessUrl?.trim() || !settings.aiUrl?.trim() || !settings.apiKey?.trim()) {
        console.warn('Paperless-AI Chat: Configuration incomplete');
        return;
      }
      
      // Add debug logging
      console.log('Paperless-AI Chat: Initializing with settings:', {
        paperlessUrl: settings.paperlessUrl,
        aiUrl: settings.aiUrl,
        hasApiKey: !!settings.apiKey,
        key: settings.apiKey
      });
  
      // Initialize chat button
      addChatButton(settings);
    });
  }
  
  // Start when the page is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
  
  // Also watch for Angular route changes
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      console.log('Paperless-AI Chat: URL changed, reinitializing...');
      initialize();
    }
  }).observe(document, {subtree: true, childList: true});