document.addEventListener('DOMContentLoaded', async () => {
    const form = document.getElementById('settingsForm');
    const successAlert = document.getElementById('alert-success');
    const errorAlert = document.getElementById('alert-error');
    const testButton = document.getElementById('test');
  
    // Load saved settings
    chrome.storage.sync.get(
      ['paperlessUrl', 'aiUrl', 'apiKey'],
      (result) => {
        document.getElementById('paperlessUrl').value = result.paperlessUrl || '';
        document.getElementById('aiUrl').value = result.aiUrl || '';
        document.getElementById('apiKey').value = result.apiKey || '';
      }
    );
  
    // Helper to show/hide alerts
    function showAlert(alert, duration = 3000) {
      alert.style.display = 'block';
      setTimeout(() => {
        alert.style.display = 'none';
      }, duration);
    }
  
    // Helper to validate URL
    function isValidUrl(string) {
      try {
        new URL(string);
        return true;
      } catch (_) {
        return false;
      }
    }
  
    // Helper to validate form
    function validateForm() {
      let isValid = true;
      const paperlessUrl = document.getElementById('paperlessUrl');
      const aiUrl = document.getElementById('aiUrl');
      const apiKey = document.getElementById('apiKey');
  
      // Reset all error messages
      document.querySelectorAll('.validation-error').forEach(el => {
        el.style.display = 'none';
      });
  
      // Validate Paperless URL
      if (!isValidUrl(paperlessUrl.value)) {
        document.getElementById('paperlessUrl-error').style.display = 'block';
        isValid = false;
      }
  
      // Validate AI URL
      if (!isValidUrl(aiUrl.value)) {
        document.getElementById('aiUrl-error').style.display = 'block';
        isValid = false;
      }
  
      // Validate API Key
      if (!apiKey.value.trim()) {
        document.getElementById('apiKey-error').style.display = 'block';
        isValid = false;
      }
  
      return isValid;
    }
  
    // Test connection
    testButton.addEventListener('click', async () => {
      if (!validateForm()) {
        showAlert(errorAlert);
        return;
      }
  
      const aiUrl = document.getElementById('aiUrl').value;
      const apiKey = document.getElementById('apiKey').value;
  
      try {
        testButton.disabled = true;
        testButton.textContent = 'Testing...';
  
        // Try to make a test request
        const response = await fetch(`${aiUrl}/health`, {
          headers: {
            'x-api-key': apiKey
          }
        });
  
        if (response.ok) {
          showAlert(successAlert);
        } else {
          showAlert(errorAlert);
        }
      } catch (error) {
        console.error('Test connection failed:', error);
        showAlert(errorAlert);
      } finally {
        testButton.disabled = false;
        testButton.textContent = 'Test Connection';
      }
    });
  
    // Save settings
    form.addEventListener('submit', (e) => {
      e.preventDefault();
  
      if (!validateForm()) {
        return;
      }
  
      const settings = {
        paperlessUrl: document.getElementById('paperlessUrl').value.trim(),
        aiUrl: document.getElementById('aiUrl').value.trim(),
        apiKey: document.getElementById('apiKey').value.trim()
      };
  
      chrome.storage.sync.set(settings, () => {
        if (chrome.runtime.lastError) {
          console.error('Error saving settings:', chrome.runtime.lastError);
          showAlert(errorAlert);
        } else {
          showAlert(successAlert);
        }
      });
    });
  
    // Input validation on blur
    document.querySelectorAll('input[type="url"]').forEach(input => {
      input.addEventListener('blur', () => {
        if (input.value && !isValidUrl(input.value)) {
          document.getElementById(`${input.id}-error`).style.display = 'block';
        } else {
          document.getElementById(`${input.id}-error`).style.display = 'none';
        }
      });
    });
  
    // Clean up URLs on blur (ensure trailing slash)
    document.querySelectorAll('input[type="url"]').forEach(input => {
      input.addEventListener('blur', () => {
        if (input.value && isValidUrl(input.value)) {
          const url = new URL(input.value);
          if (!url.pathname.endsWith('/')) {
            url.pathname += '/';
            input.value = url.toString();
          }
        }
      });
    });
  });