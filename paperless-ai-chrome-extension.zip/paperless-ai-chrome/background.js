chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'chatMessage') {
      chrome.storage.sync.get(['serverUrl', 'apiKey'], async (data) => {
        const { serverUrl, apiKey } = data;
  
        if (!serverUrl || !apiKey) {
          sendResponse({ error: 'Bitte zuerst die Konfiguration ausfüllen!' });
          return;
        }
  
        try {
          const response = await fetch(`${serverUrl}/chat/message`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-API-Key': apiKey,
            },
            body: JSON.stringify({ message: message.message }),
          });
  
          const result = await response.json();
          sendResponse({ reply: result.reply });
        } catch (error) {
          sendResponse({ error: 'Fehler bei der Kommunikation mit dem Server.' });
        }
      });
      return true;
    }
  });
  